RR DEFENCE ACADEMY BARMER — Razorpay website verification pages

सार्वजनिक सहायता नंबर: 8696517568
फाइलें: index.html, contact.html, privacy-policy.html, terms.html, refund-policy.html, delivery-policy.html

फाइलों को GitHub repository की root (main) में अपलोड करें। जब सभी फाइलें दिखने लगें, तो root website को Razorpay में जाँच हेतु दें।

Repo: https://github.com/rrdefenceacademy2-create/-rr-defence-academy-barmer
Live root URL: https://rrdefenceacademy2-create.github.io/-rr-defence-academy-barmer/

IMPORTANT: Repo में मौजूद index-3.html अभी मुफ्त CBT डेमो है; इसे न बदलें। नया index.html होम पेज बनता है और डेमो का लिंक इसमें है।

No payments yet. This site does not contain live Razorpay keys, a payment button, authenticated cloud students, or paid unlocked tests. All policies should be reviewed by the business owner before final publishing. A verified postal address, final access period, publication schedule and confirmed refund operations should be agreed before starting paid sales.

मोबाइल पर यदि ब्राउज़र डाउनलोड हुई index.html को index(1).html नाम दे दे, तो अपलोड से पहले उसे ठीक index.html नाम दें।
