# RR DEFENCE ACADEMY BARMER — Public Google Play App V2

**यह पब्लिक ₹199 टेस्ट-सीरीज़ ऐप है; निजी Admin/Student Portal नहीं। 99 रुपये की बुक शामिल नहीं है।**

## वर्तमान स्थिति (7 नवंबर 2026)

- Android Studio Kotlin app source: `app/` + Gradle files.
- GitHub Actions: `.github/workflows/build-public-android.yml`; GitHub में अपलोड करने पर टेस्ट APK बिल्ड हो सकता है।
- Signed .aab केवल Play upload signing key GitHub Actions Secrets में सुरक्षित रखने के बाद बनेगा।
- वर्तमान public GitHub repo में `test-series.html` **अभी नहीं है**। `WEBSITE_UPLOAD_TO_GITHUB/test-series.html` फाइल उसी वेबसाइट रेपो के root में जोड़ें।
- नई HTML में Google Play ऐप की खरीद Razorpay के `/api/order` को **बिना बुलाए** native Google Play Billing से जाती है।
- Android ऐप `test-series.html` से शुरू होता है; जब तक यह वेबसाइट पर नहीं है तब तक 404 मिलने पर `index.html` के लाइव डेमो पर लौटता है।
- Android source package: `com.rrdefenceacademy.barmer`; target SDK 36, Play Billing 9.1.0.
- Firebase config और D1 schema अभी सेटअप नहीं हैं। भुगतान सुरक्षा के लिए बंद है।

## Android Studio (computer)
1. इस ZIP का `RRDA_PUBLIC_PLAYSTORE_V2_PROJECT` folder extract करें।
2. Android Studio → Open → project folder.
3. SDK 36 install और Gradle sync होने दें (इंटरनेट जरूरी)।
4. `Build APK(s)` से test APK तैयार करें।
5. Release AAB के लिए सुरक्षित, स्थायी signing key बनाएँ और project file `app/release-upload.jks` + signing credentials उपलब्ध कराएँ; Android Studio > Generate Signed App Bundle भी इस्तेमाल कर सकते हैं।

## GitHub Actions (mobile-friendly)
1. इस **Android project** के files को अलग PRIVATE GitHub repository में अपलोड करें (ZIP को सीधे GitHub root में डालने से auto-unzip नहीं होगा)।
2. Actions → Build RRDA PUBLIC Android App → Run workflow → Artifacts में APK मिलेगा।
3. चार GitHub Actions secrets configure करके ही signed AAB बनेगा: ANDROID_KEYSTORE_BASE64, ANDROID_KEYSTORE_PASSWORD, ANDROID_KEY_ALIAS, ANDROID_KEY_PASSWORD. Signing secret किसी को भेजें नहीं।
4. Keystore खोने या बदलने से app update प्रभावित हो सकती है। Upload key और password सुरक्षित रखें।

## Play Console आवश्यक शर्तें
- Play Developer का सत्यापित अधिकृत वयस्क खाता, application declaration, privacy policy, data safety, content rating, screenshots, support details.
- एक non-consumable INAPP product ID `rrda_mega30_199`; price INR ₹199.
- Worker पर service account verification, Play Billing config, D1 tables, Firebase login, purchase recovery/refund checks और 12/14-day testing (जहाँ लागू) पहले पूरे हों।
- Google Play पर डिजिटल खरीद के लिए native Play Billing, **Razorpay checkout नहीं**।

## सुरक्षा
- इस ZIP में कोई Firebase admin key, Razorpay secret, Play service-account JSON, D1 private data, signing key या private question-bank नहीं है।
- कोई रियल ट्रांज़ैक्शन सक्षम नहीं किया गया।
- HTML में `REPLACE_FIREBASE_*` placeholders अभी भरने हैं; पेज लॉगिन और भुगतान सक्षम नहीं करेगा जब तक सही config और Worker कॉन्फ़िगरेशन पूरा न हो।
- कोड का API/Gradle एंड-टू-एंड build और Android डिवाइस टेस्ट इस container में Android SDK व network नहीं होने से नहीं हो सका; source को Play-ready release मानें नहीं।
