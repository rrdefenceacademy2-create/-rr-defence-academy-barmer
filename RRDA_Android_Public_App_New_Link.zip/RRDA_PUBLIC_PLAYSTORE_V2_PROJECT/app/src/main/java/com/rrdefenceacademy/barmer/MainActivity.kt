package com.rrdefenceacademy.barmer

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.widget.Toast
import com.android.billingclient.api.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/**
 * Play distribution: Google Play Billing only, NOT embedded Razorpay Checkout.
 * The purchase unlocks content ONLY after secure Google Play Developer API verification on Worker.
 * The web page and backend must be deployed/configured before building a release.
 */
class MainActivity : Activity() {
    private val site = "https://rrdefenceacademy2-create.github.io/-rr-defence-academy-barmer/test-series.html"
    private val landing = "https://rrdefenceacademy2-create.github.io/-rr-defence-academy-barmer/index.html"
    private val sitePrefix = "https://rrdefenceacademy2-create.github.io/-rr-defence-academy-barmer/"
    private val api = "https://rr-defence-payment-api.rrdefenceacademy2.workers.dev"
    private val productId = "rrda_mega30_199"
    private lateinit var web: WebView
    private lateinit var billing: BillingClient
    private var product: ProductDetails? = null
    private var pendingIdToken: String? = null
    private var purchaseReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        WebView.setWebContentsDebuggingEnabled(false)
        web.webViewClient = object : WebViewClient() {
            override fun onReceivedHttpError(view: WebView, req: WebResourceRequest, response: android.webkit.WebResourceResponse) {
                if (req.isForMainFrame && req.url.toString() == site && response.statusCode == 404) {
                    runOnUiThread { web.loadUrl(landing) }
                }
            }
            override fun onReceivedError(view: WebView, req: WebResourceRequest, error: android.webkit.WebResourceError) {
                if (req.isForMainFrame) message("इंटरनेट/वेबसाइट उपलब्ध नहीं है। कनेक्शन जाँचें।")
            }
            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                val url = req.url.toString()
                if (url.startsWith(sitePrefix)) return false
                // Open only verified app URLs. Never allow checkout redirects to external providers.
                return true
            }
        }
        web.addJavascriptInterface(PurchaseBridge(), "RRDAAndroid")
        web.loadUrl(site)
        billing = BillingClient.newBuilder(this)
            .setListener { result, purchases ->
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    purchases?.forEach { p -> processPurchase(p) }
                } else if (result.responseCode != BillingClient.BillingResponseCode.USER_CANCELED) {
                    message("Google Play खरीदारी में समस्या: ${result.debugMessage}")
                }
            }
            .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
            .enableAutoServiceReconnection()
            .build()
        billing.startConnection(object : BillingClientStateListener {
            override fun onBillingServiceDisconnected() { purchaseReady = false }
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) queryProduct()
            }
        })
    }

    private fun queryProduct() {
        val params = QueryProductDetailsParams.newBuilder().setProductList(
            listOf(QueryProductDetailsParams.Product.newBuilder()
                .setProductId(productId).setProductType(BillingClient.ProductType.INAPP).build())
        ).build()
        billing.queryProductDetailsAsync(params) { result, data ->
            product = if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                data.productDetailsList.firstOrNull()
            } else null
            purchaseReady = product != null
        }
    }

    inner class PurchaseBridge {
        @JavascriptInterface fun restore(firebaseIdToken: String) {
            runOnUiThread {
                if (web.url != site || firebaseIdToken.length !in 100..10000) return@runOnUiThread
                pendingIdToken = firebaseIdToken
                if (!billing.isReady) return@runOnUiThread
                val params = QueryPurchasesParams.newBuilder()
                    .setProductType(BillingClient.ProductType.INAPP).build()
                billing.queryPurchasesAsync(params) { result, purchases ->
                    if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                        purchases.forEach { processPurchase(it) }
                    }
                }
            }
        }
        @JavascriptInterface fun purchase(firebaseIdToken: String) {
            runOnUiThread {
                // Never let an untrusted web page initiate in-app billing.
                if (web.url != site || firebaseIdToken.length !in 100..10000) return@runOnUiThread
                if (!purchaseReady) { message("Play Billing सेटअप पूरा नहीं है; कोई भुगतान नहीं लिया गया।"); return@runOnUiThread }
                pendingIdToken = firebaseIdToken
                val pd = product ?: return@runOnUiThread
                val offer = pd.oneTimePurchaseOfferDetailsList?.firstOrNull()?.offerToken
                if (offer == null) { message("₹199 पैकेज Play Console में उपलब्ध नहीं है।"); return@runOnUiThread }
                val pp = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(pd).setOfferToken(offer).build()
                billing.launchBillingFlow(this@MainActivity, BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(pp)).build())
            }
        }
    }

    private fun processPurchase(purchase: Purchase) {
        if (purchase.purchaseState != Purchase.PurchaseState.PURCHASED || productId !in purchase.products) return
        val firebaseToken = pendingIdToken
        if (firebaseToken == null) { message("अपना खाता खोलकर खरीदारी बहाल करें।"); return }
        thread {
            try {
                val conn = URL("$api/api/googleplay/verify").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 12000
                conn.readTimeout = 12000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("Authorization", "Bearer $firebaseToken")
                val payload = JSONObject().put("productId", productId).put("purchaseToken",purchase.purchaseToken).toString()
                conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                val ok = conn.responseCode == 200
                conn.disconnect()
                runOnUiThread {
                    web.evaluateJavascript("window.rrdaPaymentCompleted(${if (ok) "true" else "false"});",null)
                    if (!ok) message("सर्वर सत्यापन बाकी है; दुबारा भुगतान न करें।")
                }
            } catch (ex: Exception) { runOnUiThread { message("नेटवर्क समस्या: भुगतान सर्वर से पुष्टि नहीं हुई।") } }
        }
    }
    private fun message(msg:String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    @Deprecated("Back navigation")
    override fun onBackPressed() { if(web.canGoBack())web.goBack() else super.onBackPressed() }
    override fun onDestroy() { if (::billing.isInitialized) billing.endConnection(); web.destroy();super.onDestroy() }
}
