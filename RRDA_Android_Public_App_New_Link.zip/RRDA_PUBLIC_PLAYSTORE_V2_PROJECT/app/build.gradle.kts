plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.rrdefenceacademy.barmer"; compileSdk = 36
    defaultConfig { applicationId = "com.rrdefenceacademy.barmer"; minSdk = 26; targetSdk = 36; versionCode = 1; versionName = "1.0.0" }
    signingConfigs {
        create("playRelease") {
            storeFile = file("release-upload.jks")
            storePassword = System.getenv("ANDROID_KEYSTORE_PASSWORD") ?: ""
            keyAlias = System.getenv("ANDROID_KEY_ALIAS") ?: ""
            keyPassword = System.getenv("ANDROID_KEY_PASSWORD") ?: ""
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            if (System.getenv("ANDROID_KEYSTORE_PASSWORD") != null) {
                signingConfig = signingConfigs.getByName("playRelease")
            }
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("com.android.billingclient:billing-ktx:9.1.0") }
