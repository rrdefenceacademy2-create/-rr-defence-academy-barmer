# Google Play Store – Android Studio SOURCE (AAB नहीं)

**इस फोल्डर में Android Studio का Kotlin source है, Google Play पर अपलोड की हुई ऐप नहीं।** इस वातावरण में Android SDK/Gradle नहीं होने से AAB बिल्ड या डिवाइस परीक्षण नहीं हुआ।

1. अधिकृत वयस्क संचालक [Google Play Console](https://play.google.com/console) खाता बनाएं ($25 एक बार का आधिकारिक पंजीकरण शुल्क)।
2. वेबसाइट `test-series.html` और सुरक्षित Cloudflare Worker लागू होने के बाद ही Android ऐप चलाएँ।
3. Play Console में एक non-consumable in-app product का ID `rrda_mega30_199` और कीमत INR ₹199 बनाएँ।
4. Worker `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` secret में अधिकृत Play Developer API service account का विवरण सेट करें; Play Console से उचित न्यूनतम अधिकार दें। `PLAY_PURCHASES_ENABLED=false` तब तक रखें जब तक खरीद/रिफंड और recovery परीक्षण न हो।
5. ऐप `compileSdk/targetSdk=36` व Billing Library 9.1.0 का source इस्तेमाल करता है; Build > Generate Signed App Bundle से AAB बनाएं। Upload key का पासवर्ड GitHub में न डालें।
6. Android ऐप में Razorpay checkout नहीं है, क्योंकि Google Play की Digital goods billing नीति अलग है।
7. बिना Firebase login और app-to-Worker verification के किसी user को purchased access नहीं मिलेगा।
8. नए व्यक्तिगत Play Console खातों पर 12 testers / 14 दिन closed testing लागू हो सकती है।
9. अंतिम रिलीज़ से पहले refund reconciliation (Play Voided Purchases), purchase restore on sign-in, error handling, Firebase verification, Play review, accessibility और device tests पूरा करें।
10. **अभी इसे Play production release न मानें; native app का स्रोत और purchase verification integration का पहला संस्करण है।**
